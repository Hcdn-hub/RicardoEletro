﻿<?
// configurações nova fake 2013
$config['host'] 	= 'mysql.nixiweb.com';
$config['user'] 	= 'u743297166_1';
$config['pass'] 	= '223345';
$config['db']		= 'u743297166_1';
$emailparaenvio 	= 'acestbh@live.com';

?>