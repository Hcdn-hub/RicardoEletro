<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="pt" lang="pt" xmlns:og="http://ogp.me/ns#" xmlns:fb="http://www.facebook.com/2008/fbml">
<!-- Mirrored from www.ricardoeletro.com.br/Produto/Playstation-4-com-500GB-NOVO-Controle-Sem-Fio-DualShock-4-Fone-de-Ouvido-Cabo-HDMI/47-4635-4638-385865 by HTTrack Website Copier/3.x [XR&CO'2013], Sat, 28 Dec 2013 00:24:55 GMT -->
<!-- Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1" />
<!-- /Added by HTTrack -->
<head>
<title>Playstation 4 com 500GB + NOVO Controle Sem Fio DualShock 4</title>
<link rel="icon" href="http://www.ricardoeletro.com.br/web/re/favicon.ico" type="image/x-icon" />
<link rel="shortcut icon" href="http://www.ricardoeletro.com.br/web/re/favicon.ico" />
<meta name="description" content='Encontre aqui Playstation 4 com 500GB + NOVO Controle Sem Fio DualShock 4 + Fone de Ouvido + Cabo HDMI com &Oacute;timos pre&ccedil;os na RicardoEletro.com. Confira!' />
<link rel="apple-touch-icon-precomposed" sizes="57x57" href="../../../images.maquinadevendas.com.br/site/re/re_57.png" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="../../../images.maquinadevendas.com.br/site/re/re_72.png" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="../../../images.maquinadevendas.com.br/site/re/re_114.png" />
<meta name="google-site-verification" content="hgorFwvgMHzXxUmeGTufBfhJDEM7AjkfeRHiN3ND8rc" />
<meta property="og:title" id="og-title" content="Playstation 4 com 500GB + NOVO Controle Sem Fio DualShock 4" /> <meta property="og:description" id="og-description" content="Encontre aqui Playstation 4 com 500GB + NOVO Controle Sem Fio DualShock 4 + Fone de Ouvido + Cabo HDMI com &Oacute;timos pre&ccedil;os na RicardoEletro.com. Confira!" />
<meta property="og:image" id="og-image" content="../../../images.maquinadevendas.com.br/50x50/produto/401490_2573107_20131114170233.jpg" />
<link href="http://www.ricardoeletro.com.br/web/re/css/IndexCSS.php?p=YToyOntzOjY6IklNQUdFUyI7czozNjoiaHR0cDovL2ltYWdlcy5tYXF1aW5hZGV2ZW5kYXMuY29tLmJyIjtzOjk6IlNJVEVfUEFUSCI7czoyOiJyZSI7fQ==&amp;v=aa281e3ef477a3cf35845a5341aaf3a5&amp;ie=&amp;a=1&amp;g=" type="text/css" rel="stylesheet">
</link>

</head>
<body>
<script>var dataLayer = [{"pageTitle":"Ricardo Eletro aqui tem Dono, na luta pelo menor pre&ccedil;o.","displayingProductDetails":"yes","productID":"385865","productSKU":"401490","productName":"Playstation 4 com 500GB + NOVO Controle Sem Fio DualShock 4 + Fone de Ouvido + Cabo HDMI","productDescription":"O PlayStation\u00ae4 \u00e9 o melhor lugar para jogar jogos din\u00e2micos\ne conectados, com gr\u00e1fico rico e alta velocidade, personaliza\u00e7\u00e3o inteligente,\nfuncionalidades sociais altamente integradas e recursos de segunda tela\ninovadores. Combinando conte\u00fado sem igual, experi\u00eancias de jogo envolventes,\ntodos os seus aplicativos favoritos de entretenimento digital e as\nexclusividades do PlayStation, o PS4 \u00e9 centrado nos jogadores, permitindo-lhes\nque joguem quando, onde e como quiserem.\u00a0\u00a0\nO PS4 permite que os melhores desenvolvedores de jogos do mundo liberem\nsua criatividade e estendam os limites do jogo por meio de um sistema que est\u00e1\nsintonizado especificamente com suas necessidades.\n\n\u00a0\n\nAten\u00e7\u00e3o! No caso de\nprodutos em pr\u00e9-venda, o prazo de entrega come\u00e7a a valer a partir do dia\noficial de Lan\u00e7amento no Brasil citado abaixo, valendo, ap\u00f3s a data, o n\u00famero\nde dias \u00fateis normais para cada regi\u00e3o.\u00a0\n\nNo caso das pr\u00e9-vendas, pedimos, por favor, que seja desconsiderado o\nprazo de entrega informado no campo \\\"simular prazo de entrega\\\".\nEm caso de d\u00favidas ou problemas, estamos sempre \u00e0 disposi\u00e7\u00e3o.\n\n\nO console PS4 est\u00e1 com lan\u00e7amento\nprevisto para o dia 29\/11\/2013. Em caso de altera\u00e7\u00e3o da data, avisaremos todos\nos clientes previamente.\u00a0\n\nAviso:\u00a0\n\n\u00a0\n\nImagem Meramente Ilustrativa","productEAN13":"","productPrice":3999,"productAvailable":"yes","productUrl":"http:\/\/www.ricardoeletro.com.br\/Produto\/Playstation-4-com-500GB-NOVO-Controle-Sem-Fio-DualShock-4-Fone-de-Ouvido-Cabo-HDMI\/47-4635-4638-385865","productPhoto":"http:\/\/images.maquinadevendas.com.br\/produto\/401490_2573107_20131114170233.jpg","productBrand":"Sony","pageDepartmentID":4635,"pageDepartment":"Games","pageCategory":"Playstation 4","pageSubCategory":"Playstation 4 Console"}];</script>
<noscript>
<iframe src="http://www.googletagmanager.com/ns.html?id=GTM-N47HTJ" height="0" width="0" style="display:none;visibility:hidden">
</iframe>
</noscript>
<script>(function(w,d,s,l,i) {w[l] = w[l] || [];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f = d.getElementsByTagName(s)[0], j=d.createElement(s), dl=l != 'dataLayer'?'&l=' + l:'';j.async = true;j.src = '/www.googletagmanager.com/gtm5445.html?id=' + i + dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','GTM-N47HTJ');</script>
<div id="fb-root">
</div>
<div id="Limit" class="">
<div id="Busca-Cemporcento" class="content-full">
<div class="busca-content">
<div class="carrinho-resumo-atualizar">
<div class="carrinho-resumo" href="http://www.ricardoeletro.com.br/Carrinho"
tipocarrinho="1">
<div class="carrinho-resumo-titulo">
<div class="carrinho-resumo-text">meu carrinho</div>
<div class="carrinho-resumo-qnt">
0 item</div>
</div>
<div class="carrinho-resumo-open">
<div class="carrinho-resumo-open-vazio-drag">
<div class="carrinho-resumo-open-vazio-top">
</div>
<div class="carrinho-resumo-open-vazio-middle">Arraste os produtos para adicionar ao carrinho de compras</div>
<div class="carrinho-resumo-open-vazio-bottom">
</div>
</div>
<div class="carrinho-resumo-open-vazio">
<div class="carrinho-resumo-open-vazio-top">
<div class="carrinho-resumo-vazio-subtotal">
<span class="valor">R$ 0,00</span>
<span class="subtotal">subtotal:</span>
</div>
<div class="carrinho-resumo-vazio-visualizar">
<img src="../../../images.maquinadevendas.com.br/site/re/button/btn_vizualisar_meu_carrinho.png" />
</div>
</div>
</div>
<div class="carrinho-resumo-open-produto">
<div class="carrinho-resumo-open-produto-top">
</div>
<div class="carrinho-resumo-open-produto-middle">
<div class="holder osX barra_resumo">
<div class="pane4" class="scroll-pane">
<div class="clear">
</div>
</div>
</div>
</div>
<div class="carrinho-resumo-open-produto-bottom">
<div class="carrinho-resumo-produto-subtotal">
<span class="valor">R$ 0,00</span>
<span class="subtotal">subtotal:</span>
</div>
<div class="carrinho-resumo-produto-visualizar">
<img src="../../../images.maquinadevendas.com.br/site/re/button/btn_vizualisar_meu_carrinho.png" />
</div>
</div>
</div>
</div>
</div>
</div>
<div class="barra-busca">
<div class="barra-busca-right">
</div>
<div class="barra-busca-left">
</div>
<div class="barra-busca-middle">
<input name="busca100" type="text" value="o que voc� procura?" id="q2" />
</div>
</div>
<div class="duvida">
<div class="interrogacao">?</div>
</div>
<div class="busca-content-bullet-open">
</div>
</div>
</div>
<div id="envelope" data-url-envelope="" style="background: #FFF">
<div class="content-min" style="background: #FFF" class="envelopamento-topo">
</div>
<div class="content-full" id="Header" >
<div id="MiddleHome">
<div class="header-content">
<div class="logo">
<a href="http://www.ricardoeletro.com.br/">
<img src="../../../images.maquinadevendas.com.br/site/re/layout/logo_re.png">
</a>
</div>
<div class="menu-cliente">
<div class="saudacao">
<div id="B2cSaudacao" >
<div class="headerSaudacaoB2C">
<span id="TipoOperador">
</span> : <b> <span id="NomeOperador">
</span> </b> | <a href="https://carrinho.ricardoeletro.com.br/b2c/Sair" id="B2CSair" title="Sair">Sair</a>
</div>
<div class="content-revenda">
<div class="revenda input-container">
<input id="revenda" name="revenda" type="text" maxlength="10" conf="[{req:true,type:'num'}]" form="Revenda">
</div>
<input class="button" id="button_revenda" type="submit" value="Recuperar Venda" onsuccess="B2c_RecuperarVenda('')" form="Revenda" enter >
</div>
</div>
<div class="container-saudacao">
<div class="cadastro-login titulo-login">
<div class="headerLogin">
<span id='LoginSaudacao'>
</span>
<span id='LinkLogin'>
</span>
</div>
</div>
<div class="text titulo">Bem-vindo(a) ao site Ricardo Eletro</div>
</div>
</div>
<div class="link-acesso">
<div class="televendas">
<div class="img-televendas">
<img src="../../../images.maquinadevendas.com.br/site/re/icons/ico_telefone.png">
</div>
<div class="content-televendas">
<div class="pelo-telefone">Compre pelo telefone: <div class="number">
<a href="http://www.ricardoeletro.com.br/Televendas" id="regraTelevendas" title="Televendas" data-fancybox-type="ajax">0300-313-9000</a>
</div>
</div>
</div>
</div>
<div class="servico-lista-casamento">
<div class="img-ldc">
<img src="../../../images.maquinadevendas.com.br/40x40/site/re/icons/ico_lista_casamento.png">
</div>
<div class="content-ldc">
<div class="para-ldc">
<div class="text">
<a href="http://www.ricardoeletro.com.br/ListaCasamento">Lista de Casamento</a>
</div>
</div>
</div>
</div>
<div class="pessoal">
<div class="img-pessoal">
<img src="../../../images.maquinadevendas.com.br/site/re/icons/ico_interrogacao.png">
</div>
<div class="content-pessoal">
<div class="pessoal">
<div class="minha-conta">
<a href="https://carrinho.ricardoeletro.com.br/Cliente/MinhaConta">Minha Conta</a>
</div>
</div>
<div class="pessoal">
<div class="meus-pedidos">
<a href="https://carrinho.ricardoeletro.com.br/Pedido/Acompanhamento">Meus Pedidos</a>
</div>
</div>
<div class="pessoal">
<div class="cancelamento">
<a class="link-cancelamento" href="http://www.ricardoeletro.com.br/Cliente/LoginRetorno/Atendimento">Cancelamento</a>
</div>
</div>
<div class="pessoal">
<div class="Atendimento">
<a href="http://www.ricardoeletro.com.br/Atendimento">Atendimento</a>
</div>
</div>
<div class="clear">
</div>
</div>
</div>
</div>
</div>
</div>
<div class="clear">
</div>
<div class="busca-content-header">
<div class="busca-carrinho">
<div class="carrinho-resumo-atualizar">
<div class="carrinho-resumo" href="http://www.ricardoeletro.com.br/Carrinho"
tipocarrinho="1">
<div class="carrinho-resumo-titulo">
<div class="carrinho-resumo-text">meu carrinho</div>
<div class="carrinho-resumo-qnt">
0 item</div>
</div>
<div class="carrinho-resumo-open">
<div class="carrinho-resumo-open-vazio-drag">
<div class="carrinho-resumo-open-vazio-top">
</div>
<div class="carrinho-resumo-open-vazio-middle">Arraste os produtos para adicionar ao carrinho de compras</div>
<div class="carrinho-resumo-open-vazio-bottom">
</div>
</div>
<div class="carrinho-resumo-open-vazio">
<div class="carrinho-resumo-open-vazio-top">
<div class="carrinho-resumo-vazio-subtotal">
<span class="valor">R$ 0,00</span>
<span class="subtotal">subtotal:</span>
</div>
<div class="carrinho-resumo-vazio-visualizar">
<img src="../../../images.maquinadevendas.com.br/site/re/button/btn_vizualisar_meu_carrinho.png" />
</div>
</div>
</div>
<div class="carrinho-resumo-open-produto">
<div class="carrinho-resumo-open-produto-top">
</div>
<div class="carrinho-resumo-open-produto-middle">
<div class="holder osX barra_resumo">
<div class="pane4" class="scroll-pane">
<div class="clear">
</div>
</div>
</div>
</div>
<div class="carrinho-resumo-open-produto-bottom">
<div class="carrinho-resumo-produto-subtotal">
<span class="valor">R$ 0,00</span>
<span class="subtotal">subtotal:</span>
</div>
<div class="carrinho-resumo-produto-visualizar">
<img src="../../../images.maquinadevendas.com.br/site/re/button/btn_vizualisar_meu_carrinho.png" />
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="barra-busca-header">
<div id="BuscaCemporcentoHeader" class="content-min">
<div class="barra-busca">
<div class="barra-busca-right" data-busca-header="1">
</div>
<div class="barra-busca-left">
</div>
<div class="barra-busca-middle">
<form action="http://www.ricardoeletro.com.br/Busca/Resultado/" method="get" id="FormBuscaHeader" >
<input type="text" value="o que voc� procura?" name="q" id="q1" />
</form>
</div>
</div>
</div>
</div>
<div class="clear">
</div>
</div>
</div>
</div>
<div class="content-full">
<div id="CategoriasHeader">
<div class="conteudo center">
<div class="coluna" style="width: 191px">
<div class="loja">
<a title="Acess�rios de Inform�tica" href="http://www.ricardoeletro.com.br/Loja/Acessorios-de-Informatica/4523">Acess�rios de Inform�tica</a>
</div>
<div class="loja">
<a title="Ar e Ventila��o" href="http://www.ricardoeletro.com.br/Loja/Ar-e-Ventilacao/4702">Ar e Ventila��o</a>
</div>
<div class="loja">
<a title="Automotivos" href="http://www.ricardoeletro.com.br/Loja/Automotivos/2553">Automotivos</a>
</div>
<div class="loja">
<a title="Beb�s" href="http://www.ricardoeletro.com.br/Loja/Bebes/2322">Beb�s</a>
</div>
<div class="loja">
<a title="Beleza & Sa�de" href="http://www.ricardoeletro.com.br/Loja/Beleza-Saude/1">Beleza & Sa�de</a>
</div>
<div class="loja">
<a title="Brinquedos" href="http://www.ricardoeletro.com.br/Loja/Brinquedos/43">Brinquedos</a>
</div>
</div>
<span class="borda-divisao">
</span>
<div class="coluna" style="width: 191px">
<div class="loja">
<a title="Cal�ados" href="http://www.ricardoeletro.com.br/Loja/Calcados/2771">Cal�ados</a>
</div>
<div class="loja">
<a title="Cama, Mesa & Banho" href="http://www.ricardoeletro.com.br/Loja/Cama-Mesa-Banho/2438">Cama, Mesa & Banho</a>
</div>
<div class="loja">
<a title="C�meras & Filmadoras" href="http://www.ricardoeletro.com.br/Loja/Cameras-Filmadoras/2">C�meras & Filmadoras</a>
</div>
<div class="loja">
<a title="Casa & Ferramentas" href="http://www.ricardoeletro.com.br/Loja/Casa-Ferramentas/1085">Casa & Ferramentas</a>
</div>
<div class="loja">
<a title="Celulares & Telefones" href="http://www.ricardoeletro.com.br/Loja/Celulares-Telefones/44">Celulares & Telefones</a>
</div>
</div>
<span class="borda-divisao">
</span>
<div class="coluna" style="width: 191px">
<div class="loja">
<a title="Colch�es" href="http://www.ricardoeletro.com.br/Loja/Colchoes/2772">Colch�es</a>
</div>
<div class="loja">
<a title="Eletrodom�sticos" href="http://www.ricardoeletro.com.br/Loja/Eletrodomesticos/256">Eletrodom�sticos</a>
</div>
<div class="loja">
<a title="Eletr�nicos" href="http://www.ricardoeletro.com.br/Loja/Eletronicos/108">Eletr�nicos</a>
</div>
<div class="loja">
<a title="Eletroport�teis" href="http://www.ricardoeletro.com.br/Loja/Eletroportateis/258">Eletroport�teis</a>
</div>
<div class="loja">
<a title="Esporte & Lazer" href="http://www.ricardoeletro.com.br/Loja/Esporte-Lazer/889">Esporte & Lazer</a>
</div>
</div>
<span class="borda-divisao">
</span>
<div class="coluna" style="width: 191px">
<div class="loja">
<a title="Games" href="http://www.ricardoeletro.com.br/Loja/Games/47">Games</a>
</div>
<div class="loja">
<a title="Inform�tica" href="http://www.ricardoeletro.com.br/Loja/Informatica/49">Inform�tica</a>
</div>
<div class="loja">
<a title="Instrumentos Musicais" href="http://www.ricardoeletro.com.br/Loja/Instrumentos-Musicais/3155">Instrumentos Musicais</a>
</div>
<div class="loja">
<a title="Malas de Viagem" href="http://www.ricardoeletro.com.br/Loja/Malas-de-Viagem/4302">Malas de Viagem</a>
</div>
<div class="loja">
<a title="M�veis" href="http://www.ricardoeletro.com.br/Loja/Moveis/2723">M�veis</a>
</div>
</div>
<span class="borda-divisao">
</span>
<div class="coluna" style="width: 191px">
<div class="loja">
<a title="Perfumaria" href="http://www.ricardoeletro.com.br/Loja/Perfumaria/890">Perfumaria</a>
</div>
<div class="loja">
<a title="Rel�gios" href="http://www.ricardoeletro.com.br/Loja/Relogios/107">Rel�gios</a>
</div>
<div class="loja">
<a title="Suplementos & Vitaminas" href="http://www.ricardoeletro.com.br/Loja/Suplementos-Vitaminas/2986">Suplementos & Vitaminas</a>
</div>
<div class="loja">
<a title="Tablets" href="http://www.ricardoeletro.com.br/Loja/Tablets/2935">Tablets</a>
</div>
<div class="loja">
<a title="Utilidades Dom�sticas" href="http://www.ricardoeletro.com.br/Loja/Utilidades-Domesticas/805">Utilidades Dom�sticas</a>
</div> </div>
</div>
<div class="clear">
</div>
</div>
<div id="Content" class="content-min">

<div id="PrecoTravado">
<div class="seta-preta">
<a href="javascript:Produto_EncolherPrecoTravado();">
<img id="encolher" src="../../../images.maquinadevendas.com.br/site/re/button/btn_seta_direita_preta.png">
</a>
</div>
<div class="posicionamento">
<img src="../../../images.maquinadevendas.com.br/promocao/32480_20131216122455.gif">
<div>
<span class="texto-escuro">por</span> <span class="texto-verde">R$ 3.999,00</span>
</div>
<div>
<span class="texto-escuro">ou</span> <span class="texto-verde-menor">12x</span> <span class="texto-escuro">de</span> <span class="texto-verde-menor">R$ 333,25</span> <span class="texto-escuro">sem juros</span>
</div>
<div>
<span class="texto-cinza-menor">ou R$ 3.995,00 � vista com 0.1% de desconto</span>
</div>
<div class="botao-comprar">
<a href="javascript:" id="btnComprar2" data-codigoproduto='401490' data-codigocomprejunto=''>
<img alt="Comprar Playstation 4 com 500GB + NOVO Controle Sem Fio DualShock 4 + Fone de Ouvido + Cabo HDMI" title="Comprar Playstation 4 com 500GB + NOVO Controle Sem Fio DualShock 4 + Fone de Ouvido + Cabo HDMI" src="../../../images.maquinadevendas.com.br/site/re/button/btn_comprar_agora2.png" />
</a>
</div>
</div>
</div>
<div class="bread-crumbs-detalhes">
<div id="Breadcrumbs">
<div class="breadcrumbs-itens">


<a href="http://www.ricardoeletro.com.br/Loja/Games/47" class="home">games</a> 
</div>
<span class="direita">
</span>
<div class="breadcrumbs-itens breadcrumbs-itens-medio">
<h2 style="display:none">playstation 4</h2>
<span class="esquerda">
</span>
<a href="http://www.ricardoeletro.com.br/Loja/Games/Playstation-4/47-4635" class="home">playstation 4</a>
</div>
<span class="direita direita-medio">
</span>
<div class="breadcrumbs-itens breadcrumbs-itens-escuro">
<h3 style="display:none">playstation 4 console</h3>
<span class="esquerda">
</span>
<a href="http://www.ricardoeletro.com.br/Loja/Games/Playstation-4/Playstation-4-Console/47-4635-4638">playstation 4 console</a>
</div>
<span class="direita direita-escuro">
</span>
<div class="clear">
</div>
</div>
</div>
<div id="ProdutoDetalhes" itemscope itemtype="http://schema.org/Product">
<div class="descricao-produto">
<div id="ProdutoDetalhesNomeProduto" itemprop="name">
<h1>Playstation 4 com 500GB + NOVO Controle Sem Fio DualShock 4 + Fone de Ouvido + Cabo HDMI</h1>
<span id="ProdutoDetalhesCodigoProduto">c�digo do produto: 401490</span>
</div>
<div class="clear">
</div>
</div>
<div id="ProdutoDetalhamento">
<div class="barra produto-detalhamento-barra">
</div>
<div id="ProdutoDetalhesFotos">
<div id="ProdutoDetalhesFotosFotoGrande">
<div class="foto">
<a href="javacript:void(0)" class="zoom" title="Playstation 4 com 500GB + NOVO Controle Sem Fio DualShock 4 + Fo... - Cod.: 401490" rel="useZoom: 'zoom1'">
<img src="../../../images.maquinadevendas.com.br/370x370/produto/401490_2573107_20131114170233.jpg" alt="Playstation 4 com 500GB + NOVO Controle Sem Fio DualShock 4 + Fone de Ouvido + Cabo HDMI" itemprop="image" />
</a>
</div>
<div id="SelosManual">
</div>
</div>
<div id="ProdutoDetalhesFotosFotosPequenas">
<ul id="items">
<li>
<div class="produto-detalhes-fotos-pequenas">
<a href='javascript:void(0)' class='zoom-gallery' title='Playstation 4 com 500GB + NOVO Controle Sem Fio DualShock 4 + Fo...' rel="[{useZoom: 'zoom1', largeImage: '', smallImage: 'http://images.maquinadevendas.com.br/370x370/produto/401490_2573107_20131114170233.jpg'}]">
<img src="../../../images.maquinadevendas.com.br/87x87/produto/401490_2573107_20131114170233.jpg" alt="Playstation 4 com 500GB + NOVO Controle Sem Fio DualShock 4 + Fone de Ouvido + Cabo HDMI" itemprop="image"/>
</a>
</div>
</li>
<li>
<div class="produto-detalhes-fotos-pequenas">
<a href='javascript:void(0)' class='zoom-gallery' title='Playstation 4 com 500GB + NOVO Controle Sem Fio DualShock 4 + Fo...' rel="[{useZoom: 'zoom1', largeImage: '', smallImage: 'http://images.maquinadevendas.com.br/370x370/produto/401490_2573108_20131114170247.jpg'}]">
<img src="../../../images.maquinadevendas.com.br/87x87/produto/401490_2573108_20131114170247.jpg" alt="Playstation 4 com 500GB + NOVO Controle Sem Fio DualShock 4 + Fone de Ouvido + Cabo HDMI" itemprop="image"/>
</a>
</div>
</li>
<li>
<div class="produto-detalhes-fotos-pequenas">
<a href='javascript:void(0)' class='zoom-gallery' title='Playstation 4 com 500GB + NOVO Controle Sem Fio DualShock 4 + Fo...' rel="[{useZoom: 'zoom1', largeImage: '', smallImage: 'http://images.maquinadevendas.com.br/370x370/produto/401490_2573109_20131114170256.jpg'}]">
<img src="../../../images.maquinadevendas.com.br/87x87/produto/401490_2573109_20131114170256.jpg" alt="Playstation 4 com 500GB + NOVO Controle Sem Fio DualShock 4 + Fone de Ouvido + Cabo HDMI" itemprop="image"/>
</a>
</div>
</li>
<li>
<div class="produto-detalhes-fotos-pequenas">
<a href='javascript:void(0)' class='zoom-gallery' title='Playstation 4 com 500GB + NOVO Controle Sem Fio DualShock 4 + Fo...' rel="[{useZoom: 'zoom1', largeImage: '', smallImage: 'http://images.maquinadevendas.com.br/370x370/produto/401490_2573110_20131114170306.jpg'}]">
<img src="../../../images.maquinadevendas.com.br/87x87/produto/401490_2573110_20131114170306.jpg" alt="Playstation 4 com 500GB + NOVO Controle Sem Fio DualShock 4 + Fone de Ouvido + Cabo HDMI" itemprop="image"/>
</a>
</div>
</li>
<li>
<div class="produto-detalhes-fotos-pequenas">
<a href='javascript:void(0)' class='zoom-gallery' title='Playstation 4 com 500GB + NOVO Controle Sem Fio DualShock 4 + Fo...' rel="[{useZoom: 'zoom1', largeImage: '', smallImage: 'http://images.maquinadevendas.com.br/370x370/produto/401490_2573111_20131114170316.jpg'}]">
<img src="../../../images.maquinadevendas.com.br/87x87/produto/401490_2573111_20131114170316.jpg" alt="Playstation 4 com 500GB + NOVO Controle Sem Fio DualShock 4 + Fone de Ouvido + Cabo HDMI" itemprop="image"/>
</a>
</div>
</li>
<li>
<div class="produto-detalhes-fotos-pequenas">
<a href='javascript:void(0)' class='zoom-gallery' title='Playstation 4 com 500GB + NOVO Controle Sem Fio DualShock 4 + Fo...' rel="[{useZoom: 'zoom1', largeImage: '', smallImage: 'http://images.maquinadevendas.com.br/370x370/produto/401490_2573112_20131114170325.jpg'}]">
<img src="../../../images.maquinadevendas.com.br/87x87/produto/401490_2573112_20131114170325.jpg" alt="Playstation 4 com 500GB + NOVO Controle Sem Fio DualShock 4 + Fone de Ouvido + Cabo HDMI" itemprop="image"/>
</a>
</div>
</li>
<li>
<div class="produto-detalhes-fotos-pequenas">
<a href='javascript:void(0)' class='zoom-gallery' title='Playstation 4 com 500GB + NOVO Controle Sem Fio DualShock 4 + Fo...' rel="[{useZoom: 'zoom1', largeImage: '', smallImage: 'http://images.maquinadevendas.com.br/370x370/produto/401490_2573113_20131114170337.jpg'}]">
<img src="../../../images.maquinadevendas.com.br/87x87/produto/401490_2573113_20131114170337.jpg" alt="Playstation 4 com 500GB + NOVO Controle Sem Fio DualShock 4 + Fone de Ouvido + Cabo HDMI" itemprop="image"/>
</a>
</div>
</li>
</ul>
</div>
</div>
<div id="ProdutoDetalhesDoProduto">
<div id="ProdutoDetalhesOpniaoDoProduto">
<div class="produto-detalhes-opniao-do-produto-left">
<div class="avaliacao-produto">
<div class="texto">opini�o dos consumidores:</div>
<div class="estrelas"itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
<span class="star star_vazia">&nbsp;</span>
<span class="star star_vazia">&nbsp;</span>
<span class="star star_vazia">&nbsp;</span>
<span class="star star_vazia">&nbsp;</span>
<span class="star star_vazia">&nbsp;</span> <div style="display:none">
<span itemprop="ratingValue">0</span>
<span itemprop="bestRating">0</span>
<span itemprop="ratingCount">0</span>
</div>
</div>
</div>
<div class="facebook-curtir">
<div class="fb-like" href="47-4635-4638-385865.html" send="false" data-width="270" show_faces="false" data-layout="standard" >
</div> </div>
</div>
<div class="produto-detalhes-opniao-do-produto-right">
<div class="indique-seus-amigos">
<div class="img">
<a id="IndiqueSeuAmigo" href="http://www.ricardoeletro.com.br/Produto/Indicacao/385865" data-fancybox-type="ajax" title="Indique para seu amigo">
<img src="../../../images.maquinadevendas.com.br/site/re/button/btn_por_email.png" alt="e-mail" />
</a>
</div>
<div class="titulo">compartilhe este produto: </div>
</div>
<div class="redes-sociais">
<div class="plus">
<div class="g-plusone" data-size="medium" data-href="Playstation 4 com 500GB + NOVO Controle Sem Fio DualShock 4 + Fone de Ouvido + Cabo HDMI">
</div> </div>
<div class="twitter">
<a href="https://twitter.com/share" class="twitter-share-button" data-url="" data-text="Playstation 4 com 500GB + NOVO Controle Sem Fio DualShock 4 + Fone de Ouvido + Cabo HDMI - RicardoEletro.com " data-lang="pt" data-related="RicardoEletro">Tweetar</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.async=true;js.src="../../../platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script> </div>
<div class="facebook">
<div style="float:left;padding:4px;">
<a id="FacebookCompartilhar">
<img src="../../../images.maquinadevendas.com.br/site/re/button/btn_compartilhar_facebook.jpg" alt="Compartilhar" />
</a>
</div>
</div>
</div>
</div>
</div>
<div id="ProdutoDetalhesValoresEFrete">
<div id="ProdutoDetalhesValoresEFreteBotoesFreteProntaEntrega">
<div id="ProdutoDetalhesValoresEFreteBotaoFrete"> <img src="../../../images.maquinadevendas.com.br/promocao/32480_20131216122455.gif" />
</div>
<div class="clear">
</div>
</div>
<div id="ProdutoDetalhesPrecoComprarAgoraGeral">
<div id="ProdutoDetalhesPrecoComprarAgora" itemprop="offers" itemscope itemtype="http://schema.org/AggregateOffer">
<p class="produto-detalhes-preco-comprar-agora">por <span class="produto-detalhes-preco-comprar-agora-preco-verde">R$</span> <span id="ProdutoDetalhesPrecoComprarAgoraPrecoDePreco" itemprop="lowPrice">3.999,00</span>
</p>
<p class="produto-detalhes-preco-comprar-agora">ou <span class="produto-detalhes-preco-comprar-agora-preco-verde">12x</span> de <span class="produto-detalhes-preco-comprar-agora-preco-verde">R$ 333,25</span>sem juros </p>
<input type="hidden" value="3999" name="total_hidden" id="total_hidden" />
<input type="hidden" value="0" name="acessorios_total_hidden" id="acessorios_total_hidden" />
<div class="preco_avista" itemprop="lowPrice">ou R$ 3.995,00 � vista com 0.1% de desconto</div>
<br>
<br>
<p id="ProdutoDetalhesPrecoComprarAgoraFormaPagamento" >
<a id="OutrasFormasPagamento" href="http://www.ricardoeletro.com.br/Pagamento/OutrasFormasPagamento/385865" data-fancybox-type="ajax" title="Formas de Pagamento">
<img src="../../../images.maquinadevendas.com.br/site/re/icons/ico_mais_cinza.png" />Veja outras formas de pagamento</a>
</p>
</div>
<div id="ProdutoDetalhesComprarAgora">
<div id="ProdutoDetalhesBotaoComprarAgora">
<a href="javascript:" id="btnComprar" data-codigoproduto='401490' data-codigocomprejunto=''>
<img alt="Comprar Playstation 4 com 500GB + NOVO Controle Sem Fio DualShock 4 + Fone de Ouvido + Cabo HDMI" title="Comprar Playstation 4 com 500GB + NOVO Controle Sem Fio DualShock 4 + Fone de Ouvido + Cabo HDMI" src="../../../images.maquinadevendas.com.br/site/re/button/btn_comprar_agora.png" />
</a>
</div>
<div class="produto-detalhes-botao-lista-desejos lista-desejos-primeira-linha-com-dados lista-desejo">
<ul>
<li>
<div>Lista de Desejos + <span class="seta-amarela">
</span>
</div>
</li>
</ul>
</div>
<div style="display: none" class="produto-detalhes-botao-lista-desejos botao-lista-desejos-informacoes lista-desejo-itens">
<ul id="listas-desejo-cliente">
<li>
<a href="https://carrinho.ricardoeletro.com.br/Cliente/LoginRetorno/ListaDesejo/Produto/385865/" class="add-nova-lista"> Adicionar nova lista &gt;&gt; </a>
</li>
</ul>
</div>
<div class="produto-detalhes-botao-lista-casamento">
<a href="https://carrinho.ricardoeletro.com.br/Cliente/LoginRetorno/ListaCasamento/AdicionarProduto/385865">Lista de Casamento +</a>
</div>
</div>
<div class="clear">
</div>
</div>
<div id="ProdutoDetalhesConsulteValorParcelas">
<div id="ProdutoDetalhesConsulteValorParcelasTexto">Consulte o valor das parcelas no cart�o</div>
<div id="ProdutoDetalhesConsulteValorParcelasSeta">
</div>
<div class="clear">
</div>
</div>
<div id="ProdutoDetalhesParcelamentoJuros">
<div style="width:165px;">
<p>1 x sem juros R$ 3.995,00</p>
<p>2 x sem juros R$ 1.999,50</p>
<p>3 x sem juros R$ 1.333,00</p>
<p>4 x sem juros R$ 999,75</p>
</div>
<div style="width:165px;">
<p>5 x sem juros R$ 799,80</p>
<p>6 x sem juros R$ 666,50</p>
<p>7 x sem juros R$ 571,29</p>
<p>8 x sem juros R$ 499,88</p>
</div>
<div style="width:165px;">
<p>9 x sem juros R$ 444,33</p>
<p>10 x sem juros R$ 399,90</p>
<p>11 x sem juros R$ 363,55</p>
<p>12 x sem juros R$ 333,25</p>
</div>
</div>
<div class="clear">
</div>
</div>
<div id="ProdutoDetalhesConsultaFrete">
<div>
<p class="produto-detalhes-consulta-frete-titulo">Consulte o frete:</p>
<p>Para saber o prazo de entrega e o valor do frete, digite o seu CEP nos campos abaixo.</p>
<p>O prazo pode variar dependendo da sua forma de entrega.</p>
</div>
<div id="ProdutoDetalhesConsultaFreteCampos">
<div id="ProdutoDetalhesConsultaFreteCamposFormConsulta">
<div class="input-container">
<input size="9" maxlength="9" name="Cep" id="Cep" type="text" conf="[{req:true,msg:'<b>CEP</b> inv�lido!',type:'cep'}]" form="ConsultaCep" >
</div>
<div class='button-submit'>
<input type="submit" id="ProdutoDetalhesBotaoOK" class="produto-frete-consulta" value="" form="ConsultaCep" onsuccess="ConsultarCep('385865')" enter />
</div>
<div id="ProdutoDetalhesDisponibilidade">
<p id="resposta" >
</p>
<p>
</p>
</div>
</div>
</div>
<div class="clear">
</div>
</div>
<div id="ProdutoDetalhesManualPrimeiroCapitulo">
<p>
<img id="BtnMaisDetalhes" src="../../../images.maquinadevendas.com.br/site/re/button/btn_mais_detalhes.png" />
</p>
</div>
</div>
</div>
<div class="clear">
</div>
<div class="seta-duas-cores-pai">
<div class="seta-duas-cores-texto-esquerda">
<span class="indicador">
</span>Aproveite tamb�m</div>
</div>
<div id="CompreJuntoProduto">
<h4>Compre junto</h4>
<ul id="items">
<li>
<div class="left">
<div class="foto">
<a href="http://www.ricardoeletro.com.br/Produto/Nobreak-700-Bivolt-New-Station-c-bateria-interna-27915-SMS/4523-4530-4547-92935">
<img src="../../../images.maquinadevendas.com.br/102x102/produto/103965_290676_20120111132644.jpg" alt="Nobreak 700 Bivolt- New Station- c/ bateria interna- 27915- SMS" />
</a>
</div>
</div>
<div class="right">
<div class="titulo">
<a href="http://www.ricardoeletro.com.br/Produto/Nobreak-700-Bivolt-New-Station-c-bateria-interna-27915-SMS/4523-4530-4547-92935">
Nobreak 700 Bivolt- New Statio...</a>
</div>
<div class="precopor">
<div class="cont">
<div class="por">por</div>
<div class="r4">R$</div>
</div>
<div class="preco">
309,90</div>
</div>
<div class="check-comprar">
<input id="CompreJunto_103965" data-idatributo="false" type="checkbox" name="CompreJunto[]" value="103965" class="checkCompreJunto" data-valor="309.9" data-atributo="false" data-atributoespecifico="false" data-codigoproduto="103965" data-fancybox-type="ajax" />
<span>
<label for="CompreJunto_103965">Comprar</label>
</span>
</div>
</div>
</li>
</ul>
</div>
<div id="ProdutoDescricao">
<div class="barra produto-detalhamento-barra">
</div>
<div class="produto-busca-interna">
<div class="produto-busca-interna-texto">Informa��es do produto:</div>
<div class="produto-busca-interna-inputs">
<div class="produto-busca-interna-lupa">
<img src="../../../images.maquinadevendas.com.br/site/re/layout/seta_busca_cinza.png" />
</div>
<div class="produto-busca-interna-input input-container">
<input type="text" id="PesquisaRapida" value="pesquise rapidamente a caracter�stica que voc� quer saber" form="PesquisaRapidaForm" maxlength="60"/>
</div>
<div class="produto-busca-interna-button button-submit">
<input type="submit" value="enviar" onsuccess="RolarResultado()" form="PesquisaRapidaForm" enter />
</div>
</div>
</div>
<div class="produto-descricao-texto-descricao">
<h3 class="subtitulo-sessao" id="DetalhesAncora">
<span class="indicador">
</span>Detalhes</h3>
<div class="descricao-produto">
<div class="iframe_produto">
<iframe id="IFRAME" src="http://sony.com.br/eletronicos/dealer-page/games/playstation4" scrolling="no" width="100%" height="2908" frameborder="0">
</iframe>
</div>
</div>
<h3 class="subtitulo-sessao">
<span class="indicador">
</span>Caracter�sticas</h3>
<div class="produto-descricao-caracteristicas">
<table cellpadding="0" cellspacing="0">
<tr class="cinza">
<td class="nome">Altura</td>
<td>33.91 cm</td>
</tr>
<tr class="">
<td class="nome">Largura</td>
<td>47.7 cm</td>
</tr>
<tr class="cinza">
<td class="nome">Comprimento</td>
<td>10.72 cm</td>
</tr>
<tr class="">
<td class="nome">Peso</td>
<td>2.8 kg</td>
</tr>
<tr class="cinza">
<td class="nome">Garantia</td>
<td> 12 meses </td>
</tr>
</table>
</div>
<h3 class="subtitulo-sessao">
<span class="indicador">
</span>Itens Inclusos</h3>
<div class="produto-descricao-caracteristicas">
<table cellpadding="0" cellspacing="0">
<tr class="">
<td colspan="2">Sistema PlayStation 4</td>
</tr>
<tr class="cinza">
<td colspan="2">Controle Dualshock 4</td>
</tr>
<tr class="">
<td colspan="2">Cabo HDMI</td>
</tr>
<tr class="cinza">
<td colspan="2">Cabo de For�a AC</td>
</tr>
<tr class="">
<td colspan="2">Fone de Ouvido com Fio</td>
</tr>
<tr class="cinza">
<td colspan="2">Cabo USB</td>
</tr>
</table>
</div>
<h3 class="subtitulo-sessao">
<span class="indicador">
</span>Fabricante</h3>
<div class="produto-descricao-caracteristicas">
<table cellpadding="0" cellspacing="0">
<tr>
<td colspan="2">Sony</td>
</tr>
<tr class="cinza">
<td class="nome" rowspan="6">SAC:</td>
<td>4003-7669 para Capitais e Regi�es Metropolitanas</td>
</tr>
<tr class="cinza">
<td>0800-880-7669 Demais Localidades</td>
</tr>
</table>
</div>
<div class="veja-tambem-content">
<div class="abas">
<div class="right">
<div class="aba-avaliacao aba-ativa">confira todas as avalia��es feitas para este produto</div>
</div>
</div>
<div class="comentarios-avaliacao" produtoid="385865">
</div>
</div>
</div>
</div>
</div>
<script type="text/javascript" src="../../../static.criteo.net/js/universal/v0_5_4/criteo_ld.js" async="true">
</script>
<script type="text/javascript">var DADOS_CRITEO_CONF = [[{pageType: 'product','Customer ID': '','Site Type': '','Product ID': '401490'}], [3498, 'ppr', 'us.', '110', [[7714713, 7714714]], {'Customer ID': ['ci', 0], 'Site Type': ['site_type', 0], 'Product ID': ['i', 0]}]];ProcessaDadosCriteo();</script>
</div>

<style> #modal .conteudo .campodados .nome {padding: 1px 3px 1px 1px !important;background:#ffffff !important;height: 24px !important;margin-bottom:4px;}#modal .conteudo .campodados .nome input {height: 22px !important;}#modal .conteudo .campodados .validacao .email {padding:1px;background:#ffffff !important;height: 24px !important;}#modal .conteudo .campodados .validacao .email input {height: 22px !important;}#modal .conteudo .campodados .validacao {margin-top:0px !important;}#FormCaptacaoCliente #box_msg_retorno {color: #ffffff;float: left;font-size: 12px;font-weight: bold;padding-top: 1px;background:#B72025;padding:1px;}</style>
<div id="modal" style="display:none;">
<div class="fundo">
<div class="fechar" title="fechar">
</div>
<div class="conteudo">
<form action="#" id="FormCaptacaoCliente">
<div class="sexo">
<div class="homem">
<input type="radio" id="Homem" value="M" name="Sexo" tabindex="1">
</div>
<div class="mulher">
<input type="radio" id="Mulher" value="F" name="Sexo" tabindex="2">
</div>
</div>
<div class="campodados">
<div class="nome">
<input type="text" id="SeuNome" name="Nome" maxlength="20" tabindex="3">
</div>
<div class="validacao">
<div class="email">
<input type="text" id="SeuEmail" name="Email" maxlength="60" tabindex="4">
</div>
<div id="garantadesconto" tabindex="5">
</div>
</div>
</div>
<div class="box_msg" id="box_msg_retorno">
<div class="ErrorValidate">
</div>
</div>
</form>
</div>
</div>
</div>
<div class="clear">
</div>
<div id="Footer" class="content-full">
<div id="FooterContent">
<div class="condicoes">
<div class="barra">
</div>
<div class="text-condicoes">Os pre�os e condi��es de pagamento divulgados no site da Ricardo Eletro, s�o exclusivos para compras atrav�s deste, n�o valendo necessariamente para a rede de lojas f�sicas e televendas.</div>
</div>
<div class="busca-footer">
<div class="center">
<div class="barra-footer">
<div id="BuscaCemporcentoFooter" class="content-min">
<div class="barra-busca">
<div class="barra-busca-right" href="http://www.ricardoeletro.com.br/Busca/Resultado/">
</div>
<div class="barra-busca-left">
</div>
<div class="barra-busca-middle">
<input type="text" value="o que voc� procura?" name="busca100" />
</div>
</div>
</div>
</div>
</div>
</div>
<div class="content-footer">
<div class="center footer-content">
<div class="content-right">
<div class="titulo">redes sociais</div>
<div class="social">
<p>
<a class="twitter-follow-button" href="javascript:FollowTwitter('http://www.ricardoeletro.com.br/', 'RicardoEletro');">
<img src="../../../images.maquinadevendas.com.br/site/re/button/btn_twitter.png" alt="Seguir" />
</a>
</p>
<br />
<p>
<div class="fb-like-box" data-href="http://www.facebook.com/pages/Ricardo-Eletrocom-Oficial/194775443140?v=wall&amp;ref=nf" data-width="250" data-height="200" data-show-faces="true" data-stream="false" data-header="false">
</div>
</p>
</div>
</div>
<div class="content-left">
<div class="nossa-historia">
<a href="http://www.ricardoeletro.com.br/Hotsite/Html/4172">
<span class="titulo">nossa hist�ria</span> <span class="texto">A Ricardo Eletro � uma das cinco maiores redes de varejo de eletrodom�sticos do Brasil. Atualmente conta com mais de 290 lojas. <b>Saiba mais.</b>
</span>
</a>
</div>
<div class="institucional">
<div class="titulo">institucional</div>
<div class="content">
<div class="text ponto">
<a href="http://www.ricardoeletro.com.br/Institucional/Index/NossasLojas">Nossas Lojas</a>
</div>
<div class="text ponto">
<a href="http://www.sistematrabalheconosco.com.br/ricardoeletro" target="_blank">Trabalhe Conosco</a>
</div>
<div class="text">
<a href="http://www.ricardoeletro.com.br/MapaSite/Exibicao">Mapa do Site</a>
</div>
<div class="clear">
</div>
</div>
</div>
<div class="televendas">
<div class="titulo">televendas</div>
<div class="content">
<div class="text">0300-313-9000</div>
<div class="clear">
</div>
</div>
</div>
<div class="servicos">
<div class="titulo">servi�os</div>
<div class="content">
<div class="text ponto">
<a href="http://www.ricardoeletrocursos.com.br/">Cursos Online</a>
</div>
<div class="text ponto">
<a href="http://www.ricardoeletro.com.br/Hotsite/Html/4138">Garantia Estendida</a>
</div>
<div class="text">
<a href="http://www.ricardoeletroviagens.com.br/" target="_blank">Viagens</a>
</div>
<div class="clear">
</div>
<div class="text ponto">
<a href="http://www.ricardoeletro.com.br/ListaCasamento">Lista de Casamento</a>
</div>
<div class="text ponto">
<a href="http://www.ricardoeletrofotos.com.br/">Revela��o Digital</a>
</div>
<div class="text">
<a href="http://www.ricardoeletro.com.br/ListaDesejo/Gestao">Central de Listas</a>
</div>
<div class="clear">
</div>
</div>
</div>
<div class="duvidas">
<div class="titulo">d�vidas</div>
<div class="content">
<div class="text ponto">
<a href="http://www.ricardoeletro.com.br/Atendimento">Central de Atendimento</a>
</div>
<div class="text ponto">
<a class="link-cancelamento" href="http://www.ricardoeletro.com.br/Cliente/LoginRetorno/Atendimento">Cancelamento</a>
</div>
<div class="text">
<a href="http://www.ricardoeletro.com.br/Atendimento?aid=18900341&amp;a=trocadevolucao">Troca &amp; Devolu��o</a>
</div>
<div class="clear">
</div>
<div class="text ponto">
<a href="http://www.ricardoeletro.com.br/Atendimento/Index/privacidade">Termo de Uso e Pol�tica de Privacidade</a>
</div>
<div class="text">
<a href="http://www.ricardoeletro.com.br/Atendimento?aid=18900341">Entrega de Produtos</a>
</div>
<div class="clear">
</div>
</div>
</div>
<div class="forma-pagamento">
<div class="titulo">formas de pagamento</div>
<div class="content">
<div class="text ponto">Cart�es de Cr�dito</div>
<div class="text">Boleto</div>
<div class="clear">
</div>
</div>
<div class="img-pagamento">
<img src="../../../images.maquinadevendas.com.br/site/re/icons/ico_bandeiras_cartoes.jpg">
</div>
</div>
</div>
<div class="content-middle">
<div class="titulo">certifica��o e seguran�a</div>
<div class="certificado-seguranca">
<div class="ebit">
<a id="seloEbit" href="http://www.ebit.com.br/ricardo-eletro" target="_blank" >
<img id="ImgSeloEbit" alt="Ebit" />
</a>
</div>
<div class="site-blindado">
<a href="https://selo.siteblindado.com.br/verificar?url=www.ricardoeletro.com.br" title="Visualizou o selo Site Blindado? Navegue tranquilamente, esse site est� BLINDADO CONTRA ATAQUES. Realizamos milhares de testes simulando ataques de hacker, para garantir a seguran�a do site. Clique no selo e confira o certificado." target="_blank">
<img id="ImgSiteBlindado" alt="Visualizou o selo Site Blindado? Navegue tranquilamente, esse site est� BLINDADO CONTRA ATAQUES. Realizamos milhares de testes simulando ataques de hacker, para garantir a seguran�a do site. Clique no selo e confira o certificado." oncontextmenu="alert('C�pia Proibida por Lei - Site Blindado� � marca registrada de Site Blindado S.A.'); return false;" style="width:115px;height:32px;border:none;"/>
</a>
</div>
<div class="clear-sale">
<img src="../../../images.maquinadevendas.com.br/site/re/icons/icon_clearSale.png">
</div>
<div class="buscape">
<img src="../../../images.maquinadevendas.com.br/site/re/icons/icon_buscape.png">
</div>
</div>
</div>
<div class="clear">
</div>
</div>
</div>
<div class="center" id="DireitosReservados">
<div class="content">
<div class="img-seguranca">
<img src="../../../images.maquinadevendas.com.br/site/re/icons/icon_uniCert.png">
</div>
<div class="text">RN COMERCIO VAREJISTA S.A - CNPJ:13.481.309/0101-55 - Inscri��o Estadual: 145.350.855.116 - Rua Luigi Galvani, n� 70 - 4� andar / S�o Paulo - SP - CEP: 04575-020<br />Endere�o exclusivo para o envio/recebimento de correspond�ncia da loja virtual.<br />Copyright � 2012 ricardoeletro.com.br. Todos os direitos reservados � M�quina de Vendas Ltda.</div>
</div>
</div>
</div>
</div>
</div>
</div>
<script type="text/javascript">var google_conversion_id = 981530582;var google_conversion_language = "en";var google_conversion_format = "3";var google_conversion_color = "666666";var google_conversion_label = "l3SZCKLB7gIQ1u-D1AM";var google_conversion_value = 0;var google_remarketing_only = true;var google_custom_params = {pid: ['401490'],ploja: [47],pcat: [4635],pscat: [4638],value: ['3999'],et: 'Produto',sid: '1',g:'',age: ''};</script>
<script type="text/javascript" src="../../../www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="http://www.googleadservices.com/pagead/conversion/981530582/?label=l3SZCKLB7gIQ1u-D1AM&amp;guid=ON&amp;script=0"/>
</div>
</noscript>
<div style='display:none;'>OUTRO - </div>
<script type="text/javascript">var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));</script>
<script type="text/javascript">document.write(unescape("%3Cscript src='//i.btg360.com.br/bs.js' type='text/javascript'%3E%3C/script%3E"));</script>
</body>
<!-- Mirrored from www.ricardoeletro.com.br/Produto/Playstation-4-com-500GB-NOVO-Controle-Sem-Fio-DualShock-4-Fone-de-Ouvido-Cabo-HDMI/47-4635-4638-385865 by HTTrack Website Copier/3.x [XR&CO'2013], Sat, 28 Dec 2013 00:25:08 GMT -->
</html>
